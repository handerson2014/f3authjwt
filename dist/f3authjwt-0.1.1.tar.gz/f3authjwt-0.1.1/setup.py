from setuptools import setup

setup(name='f3authjwt',
      version='0.1.1',
      description='Module to secure endpoints with jwt token in ferris 3 framework',
      url='https://github.com/handerson2014/ferris-authjwt.git',
      author='Handerson Contreras',
      author_email='handerson.contreras@gmail.com',
      license='MIT',
      packages=['f3authjwt'],
      install_requires=['PyJWT', 'ferris'],
      zip_safe=False)
